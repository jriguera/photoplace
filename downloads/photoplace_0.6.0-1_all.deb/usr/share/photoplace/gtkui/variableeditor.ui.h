char *s = N_("Exit");
char *s = N_("PhotoPlace");
char *s = N_("Variables to make the KML:");
