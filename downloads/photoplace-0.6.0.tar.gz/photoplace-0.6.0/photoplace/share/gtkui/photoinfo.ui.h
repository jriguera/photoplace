char *s = N_("Add a new Property");
char *s = N_("Add or delete Property:");
char *s = N_("Delete Property");
char *s = N_("PhotoPlace");
char *s = N_("Property to add/delete");
