char *s = N_("Checks if XML data is well formed, otherwise, the content will not be considered as XML data. \n"
             "Note that contents will be checked after placing them in a (virtual) <div> section.");
char *s = N_("Close this window");
char *s = N_("Create an empty template");
/* toolbar templates, menu */
char *s = N_("Exit");
/* toolbar templates, menu */
char *s = N_("Load");
char *s = N_("Load a template from file");
/* toolbar templates, menu */
char *s = N_("New");
char *s = N_("PhotoPlace");
/* toolbar templates, menu */
char *s = N_("Recover");
char *s = N_("Recover the contents from the original template");
/* toolbar templates, menu */
char *s = N_("Save");
char *s = N_("Save the document in the template file");
/* toolbar templates, menu */
char *s = N_("Validate");
