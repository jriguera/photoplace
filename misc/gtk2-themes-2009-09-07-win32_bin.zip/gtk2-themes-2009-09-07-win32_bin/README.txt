
GTK+ themes and theme engines for MS Windows.

Packaged and compiled by Alexander Shaduri <ashaduri 'at' gmail.com>

The latest version may be obtained at
http://gtk-win.sourceforge.net

You will need at least GTK+ version 2.14.0 for installation.
Unpack to wherever your GTK+ is installed.

See license_themes.txt for license information.

For more information about GTK+ visit http://www.gtk.org

